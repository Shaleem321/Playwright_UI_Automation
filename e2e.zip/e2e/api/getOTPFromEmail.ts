import Imap from "imap-simple";
import { simpleParser } from "mailparser";
import { getEnvVariable } from "../utilities/env.utils";

export async function getLatestOtp(): Promise<string | null> {
  // Get user and password using getEnvVariable
  const gmailUser = getEnvVariable("email");
  const gmailPass = getEnvVariable("password");

  // Ensure user and password are defined to satisfy type requirements
  if (!gmailUser || !gmailPass) {
    throw new Error("email and password must be set in environment variables.");
  }

  try {
    const connection = await Imap.connect({
      imap: {
        user: gmailUser,
        password: gmailPass,
        host: "imap.gmail.com",
        port: 993,
        tls: true,
        tlsOptions: {
          rejectUnauthorized: false
        },
        authTimeout: 10000,
      },
    });
    
    console.log("✅ Successfully connected to Gmail IMAP");

    console.log("📬 Opening INBOX...");
    await connection.openBox("INBOX");
    console.log("✅ INBOX opened successfully");

    // search for last 5 unseen emails in the last 5 minutes
    const searchCriteria = ["UNSEEN", ["SINCE", new Date(Date.now() - 5 * 60000)]];
    const fetchOptions = { bodies: ["HEADER", "TEXT"], markSeen: true };

    const results = await connection.search(searchCriteria, fetchOptions);

    if (!results || results.length === 0) {
      await connection.end();
      return null;
    }

    // parse the most recent email
    const latest = results[results.length - 1];
    
    const allParts = latest.parts.map(p => p.body).join("\n");
    const parsed = await simpleParser(allParts);

    const text = parsed.text || "";
    const html = parsed.html || "";

    // regex to find a 6-digit OTP
    const match = (text + html).match(/\b\d{6}\b/);
    
    if (match) {
      console.log("✅ Found OTP:", match[0]);
    } else {
      console.log("❌ No 6-digit OTP found in email content");
      console.log("🔍 Email content preview:", (text + html).substring(0, 200) + "...");
    }

    await connection.end();
    console.log("🔌 Connection closed");
    return match ? match[0] : null;
    
  } catch (error) {
    throw error;
  }
}
