import { getEnvVariable } from "@utilities/env.utils";
import { AuthDetails } from "@interfaces/auth.interface";
import { TestCaseData } from "@interfaces/testcase.data.interface";

interface SignUpTestCaseData {
  testCaseData: TestCaseData;
  loginDetails: AuthDetails;
  userRoles: string;
}

const loginTestData: { [key: string]: SignUpTestCaseData } = {
  "superAdmin-login-Data": {
    loginDetails: {
      email: getEnvVariable('email'),
      password: `TestPASS66$$`,
      skipFlag: getEnvVariable("skipGlobalLogin"),
      userRole: "Super Admin",
    },
    userRoles: "super_admin",
    testCaseData: {
      tags: "@regression @signup",
      testCase: "superAdminLogin",
      testDescription: "Validate user is able to login as Super Admin",
      testSummary: "Verify user is able to login as Super Admin",
    },
  },
  "merchant-login-Data": {
    loginDetails: {
      email: getEnvVariable('email'),
      password: `TestPASS66$$`,
      skipFlag: getEnvVariable("skipGlobalLogin"),
      userRole: "Merchant",
    },
    userRoles: "merchant",
    testCaseData: {
      tags: "@regression @signup",
      testCase: "merchantLogin",
      testDescription: "Validate user is able to login as Merchant",
      testSummary: "Verify user is able to login as Merchant",
    },
  },
  "gameDev-login-Data": {
    loginDetails: {
      email: getEnvVariable('email'),
      password: `TestPASS66$$`,
      skipFlag: getEnvVariable("skipGlobalLogin"),
      userRole: "Game Dev",
    },
    userRoles: "game_dev",
    testCaseData: {
      tags: "@regression @signup",
      testCase: "gameDevLogin",
      testDescription: "Validate user is able to login as Game Dev",
      testSummary: "Verify user is able to login as Game Dev",
    },
  }
};

export function getLoginInData(testCase: string): SignUpTestCaseData {
  const data = loginTestData[testCase];
  if (!data) {
    throw new Error(`Test case data not found for: ${testCase}`);
  }
  return data;
}
