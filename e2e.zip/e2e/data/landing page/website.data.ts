import { TestCaseData } from "@interfaces/testcase.data.interface";

interface WebsiteTestCaseData {
  testCaseData: TestCaseData;
  url: string;
}

const websiteTestData: { [key: string]: WebsiteTestCaseData } = {
  "make-reservation": {
    testCaseData: {
      tags: "@regression @website",
      testCase: "make-reservation",
      testDescription: "Validate user is able to make reservation",
      testSummary: "Verify user is able to make reservation",
    },
    url: "https://luxodd.com/pre-order",
  },

};

export function getWebsitePageData(testCase: string): WebsiteTestCaseData {
  const data = websiteTestData[testCase];
  if (!data) {
    throw new Error(`Test case data not found for: ${testCase}`);
  }
  return data;
}
