import { test as base } from "@playwright/test";
import { WebsitePage } from "@page/landing page/website.page";


type TestFixtures = {
  lnWebsitePage: WebsitePage;
};

export const test = base.extend<TestFixtures>({
  lnWebsitePage: async ({ page }, use) => {
    const lnWebsitePage = new WebsitePage(page, base.info());
    await use(lnWebsitePage);
  },

});
