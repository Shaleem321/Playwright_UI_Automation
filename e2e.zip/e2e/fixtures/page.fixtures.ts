import { test as base } from "@playwright/test";
import { LoginPage } from "@page/admin/login/login.page";


type TestFixtures = {
  loginPage: LoginPage;
};

export const test = base.extend<TestFixtures>({
  loginPage: async ({ page }, use) => {
    const signUpPage = new LoginPage(page, base.info());
    await use(signUpPage);
  },

});
