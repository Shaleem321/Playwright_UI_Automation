export interface AuthDetails {
  password: string;
  email: string;
  verifySignUpPage?: string;
  skipFlag?: string;
  userRole?: string;
}

