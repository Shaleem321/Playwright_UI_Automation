export interface TestCaseData {
  tags: string;
  testCase: string;
  testDescription: string;
  testSummary: string;
}

export interface JiraMetaData {
  jiraStoryId: string;
  jiraTestId: string;
}
