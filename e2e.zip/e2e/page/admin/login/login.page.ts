import { Page, TestInfo, test } from "@playwright/test";
import { PlaywrightActionFactory } from "@utilities/playwright.actions.utils";
import { PlaywrightVerificationFactory } from "@utilities/playwright.verifications.utils";
import { LocatorInfo } from "@interfaces/locator.info.interface";
import { getEnvVariable } from "@utilities/env.utils";
import { getLatestOtp } from "api/getOTPFromEmail";

export class LoginPage {
  private readonly page: Page;
  private readonly testInfo: TestInfo;
  private readonly playwrightActionsFactory: PlaywrightActionFactory;
  private readonly playwrightVerificationsFactory: PlaywrightVerificationFactory;
  private readonly locators: { [key: string]: LocatorInfo };
  private readonly url: string;
  /**
   * * @param page
   * @param testInfo
   */
  constructor(page: Page, testInfo: TestInfo) {
    this.page = page;
    this.testInfo = testInfo;
    this.playwrightActionsFactory = new PlaywrightActionFactory(page, testInfo);
    this.playwrightVerificationsFactory = new PlaywrightVerificationFactory(page, testInfo);
    this.url = getEnvVariable("adminURL");

    // Locators for the first step (email entry)
    this.locators = {
      goToConsoleButton: {
        description: "go to Console button",
        locator: this.page.locator(`//span[contains(text(), 'Go to console')]`),
      },
      emailInput: {
        description: "email Input Field",
        locator: this.page.locator(`//input[@placeholder="info@gmail.com"]`),
      },
      sendVerificationCodeButton: {
        description: "send Verification Code Button",
        locator: this.page.locator(`(//button[@type="button"])[1]`),
      },
      verificationCodeInput: {
        description: "verification Code Input Field",
        locator: this.page.locator(`//label[contains(text(), 'Verification Code ')]//following::input`),
      },
      verifySignInButton: {
        description: "verification And Sign In Button",
        locator: this.page.locator(`//button[@type="submit"]`),
      }, 
      continueButton: {
        description: "continue Button",
        locator: this.page.locator(`(//label[contains(text(), "Super Admin")]//following::button)[1]`),
      },
      dashboardHeadingText: {
        description: "dashboard Heading Text",
        locator: this.page.locator(`//h1[1]`),
      },
      dynamicLocator:{
       description: "dynamic Locator",
       locator: this.page.locator(""),
      },
    };
  }

  public async navigateToSignUpPage(): Promise<void> {
    await test.step("Navigate to sign up page", async () => {
      await this.playwrightActionsFactory.navigateToURL(this.url);
      await this.playwrightActionsFactory.waitForSelector(this.locators.goToConsoleButton);
      await this.playwrightActionsFactory.click(this.locators.goToConsoleButton);
    });
  }

  public async fillInputDetails(): Promise<void> {
    await test.step("Navigate to sign up page", async () => {
      await this.playwrightActionsFactory.waitForDomLoad();
      await this.playwrightActionsFactory.waitForSelector(this.locators.emailInput);
      await this.playwrightActionsFactory.sendKeys(this.locators.emailInput, getEnvVariable('email'));
      await this.playwrightActionsFactory.waitForSec(2);
      await this.playwrightActionsFactory.waitForSelector(this.locators.sendVerificationCodeButton);
      await this.playwrightActionsFactory.forceClick(this.locators.sendVerificationCodeButton);
    });
  }

  public async getVerificationCode(): Promise<string> {
    let otp: string | null = null;
    await test.step("Fetch the verification code from the email", async () => {
      for (let i = 0; i < 6; i++) { // retry 6 times (30s total)
        otp = await getLatestOtp();
        if (otp) break;
        await new Promise(resolve => setTimeout(resolve, 5000)); // wait 5 seconds before retry
      }
    });
    
    if (!otp) {
      throw new Error("Failed to retrieve verification code after 6 attempts");
    }
    
    return otp;
  }

  public async verifyAndSignIn(otp: string): Promise<void> {
    await test.step("Enter the email and verify", async () => {
      await this.playwrightActionsFactory.waitForSec(2);
      await this.playwrightActionsFactory.waitForDomLoad();
      await this.playwrightActionsFactory.waitForSelector(this.locators.verificationCodeInput);
      await this.playwrightActionsFactory.sendKeys(this.locators.verificationCodeInput, otp);
      await this.playwrightActionsFactory.waitForSelector(this.locators.verifySignInButton);
      await this.playwrightActionsFactory.forceClick(this.locators.verifySignInButton);
    });
  }

  public async selectUserRole(userRole: string): Promise<void> {
    await test.step("Select the user role", async () => {
      await this.playwrightActionsFactory.waitForDomLoad();
      this.locators.dynamicLocator.description = `Locator for ${userRole} page`;
      this.locators.dynamicLocator.locator = this.page.locator(`//input[@value="${userRole}"]`);
      await this.playwrightActionsFactory.waitForSelector(this.locators.dynamicLocator);
      await this.playwrightActionsFactory.selectRadioButtonOrCheckBox(this.locators.dynamicLocator);
      await this.playwrightActionsFactory.click(this.locators.continueButton);

    });
  }

  public async verifyUserSignedIn(userRole: string): Promise<void> {
    await test.step("Select the user role", async () => {
      await this.playwrightActionsFactory.waitForDomLoad();
      await this.playwrightActionsFactory.waitForSelector(this.locators.dashboardHeadingText);
      await this.playwrightVerificationsFactory.expectElementExist(this.locators.dashboardHeadingText)
      this.locators.dynamicLocator.description = `Locator for ${userRole} page`;
      this.locators.dynamicLocator.locator = this.page.locator(`//div[contains(text(), '${userRole}')]`);

    });
  }
}
