import { Page, TestInfo, test } from "@playwright/test";
import { PlaywrightActionFactory } from "@utilities/playwright.actions.utils";
import { PlaywrightVerificationFactory } from "@utilities/playwright.verifications.utils";
import { LocatorInfo } from "@interfaces/locator.info.interface";
import { getEnvVariable } from "@utilities/env.utils";

export class WebsitePage {
  private readonly page: Page;
  private readonly testInfo: TestInfo;
  private readonly playwrightActionsFactory: PlaywrightActionFactory;
  private readonly playwrightVerificationsFactory: PlaywrightVerificationFactory;
  private readonly locators: { [key: string]: LocatorInfo };
  private readonly url: string;
  /**
   * * @param page
   * @param testInfo
   */
  constructor(page: Page, testInfo: TestInfo) {
    this.page = page;
    this.testInfo = testInfo;
    this.playwrightActionsFactory = new PlaywrightActionFactory(page, testInfo);
    this.playwrightVerificationsFactory = new PlaywrightVerificationFactory(page, testInfo);
    this.url = getEnvVariable("landingURL");

    // Locators for the first step (email entry)
    this.locators = {
      dynamicLocator: {
        description: "",
        locator: this.page.locator(""),
      },
      preOrderSaveButton: {
        description: "Pre Order Save Button",
        locator: this.page.locator("//div[@class='container']//div[@class='text']//button"),
      },
      reservationEmailInput: {
        description: "Reservation Email Input",
        locator: this.page.locator("//input[@autocomplete='email']"),
      },
        makeReservationButton: {
          description: "Make Reservation Button",
          locator: this.page.locator("//button[@class='reservation-button']"),
        },
        reservationSuccessful: {
          description: "Reservation Successful",
          locator: this.page.locator("//a[normalize-space()='Pre-Order']"),
        },
    };
  }

  public async goto(): Promise<void> {
    await test.step("Navigate to the Ticket page", async () => {
      await this.playwrightActionsFactory.navigateToURL(this.url);
    });
  }

  public async makerReservation(email: string): Promise<void> {
    await test.step("Make a reservation", async () => {
      await this.playwrightActionsFactory.waitForDomLoad();
      await this.playwrightActionsFactory.waitForSec(2);
      await this.playwrightActionsFactory.waitForSelector(this.locators.preOrderSaveButton);
      await this.playwrightActionsFactory.click(this.locators.preOrderSaveButton);
      await this.playwrightActionsFactory.waitForSelector(this.locators.reservationEmailInput);
      await this.playwrightActionsFactory.sendKeys(this.locators.reservationEmailInput, email);
      await this.playwrightActionsFactory.click(this.locators.makeReservationButton);
    });
  }

  public async verifyReservationSuccessful(url: string): Promise<void> {
    await test.step("Verify the reservation successful", async () => {
      await this.playwrightActionsFactory.waitForDomLoad();
      await this.playwrightActionsFactory.waitForSec(5);
      await this.playwrightVerificationsFactory.verifyCurrentUrl(url);
    });
  }

}

