import { logTestCaseData } from "@utilities/test.helper.utils";
import { getLoginInData } from "@data/admin/signup/sign.data";
import { test as setup } from "@fixtures/page.fixtures";
import path from "path";
import fs from "fs";

const testCases = [
  'superAdmin-login-Data',
  'merchant-login-Data',
  'gameDev-login-Data'
];

testCases.forEach((testCaseId) => {
  const loginTestScenario = getLoginInData(testCaseId);
  const { skipFlag } = loginTestScenario.loginDetails;
  const role = loginTestScenario.userRoles;

    if (skipFlag === "true") {
      return;
    }

  setup(
    `
        Test case: '${loginTestScenario.testCaseData.testCase}'	
        Description: '${loginTestScenario.testCaseData.testDescription}'
        Tags: '${loginTestScenario.testCaseData.tags}'
      `,
    async ({ loginPage, page }) => {
      logTestCaseData(setup.info(), loginTestScenario.testCaseData);

      await setup.step(`Navigate to signup page and enter ${role} email` , async () => {
        await loginPage.navigateToSignUpPage();
        await loginPage.fillInputDetails();
      });

      await setup.step(`Fetch and enter ${role} verification code`, async () => {
      const otp = await loginPage.getVerificationCode();
      await loginPage.verifyAndSignIn(otp);
      });

      await setup.step(`Select the ${role} role and continue`, async () => {
        await loginPage.selectUserRole(loginTestScenario.userRoles);
        await loginPage.verifyUserSignedIn(loginTestScenario.loginDetails.userRole!);
        });
        
      await setup.step("Save user browser state into Cookies", async () => {
        const storageStateDir = path.resolve(__dirname, "../../../cookies");
        const storageStatePath = path.resolve(storageStateDir, `${role}.json`);
        if (!fs.existsSync(storageStatePath)) {
          fs.mkdirSync(storageStateDir, { recursive: true });
        }
        await page.context().storageState({ path: storageStatePath });
      });
    }
  );
});
