import { logTestCaseData } from "@utilities/test.helper.utils";
import { test } from "@fixtures/landing.fixtures";
import { getWebsitePageData } from "@data/landing page/website.data";
import { getEnvVariable } from "@utilities/env.utils";

test.describe("Feature: Website", () => {

const ticketTestScenario1 = getWebsitePageData("make-reservation");

  test(`Test case: '${ticketTestScenario1.testCaseData.testCase}'	
    Description: '${ticketTestScenario1.testCaseData.testDescription}'   
    Tags: '${ticketTestScenario1.testCaseData.tags}'
      `, async ({ lnWebsitePage }) => {
    logTestCaseData(test.info(), ticketTestScenario1.testCaseData);

    await test.step("When the user make a reservation", async () => {
      await lnWebsitePage.goto();
      await lnWebsitePage.makerReservation(getEnvVariable("email"));
    });
    await test.step("Then the reservation should be successful", async () => {
      await lnWebsitePage.verifyReservationSuccessful(ticketTestScenario1.url);
    });
  });
});
