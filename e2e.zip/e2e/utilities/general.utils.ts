import { Page, test } from "@playwright/test";
import fs from "fs";
import path from "path";

const FILE_BASE_PATH = `e2e/data/files/`;
/**
 * Intercepts all network requests in Playwright and adds the x-dhauth-token header.
 * @param page Playwright Page object
 * @param token Optional token value (defaults to 'notsupersecret_but_stillakindofpwd')
 */
export async function addHeaderToBrowser(page: Page, token = "notsupersecret_but_stillakindofpwd"): Promise<void> {
  console.log("Adding header to browser");
  await page.route("**", async (route, request) => {
    const headers = {
      ...request.headers(),
      "x-dhauth-token": token,
    };
    await route.continue({ headers });
  });
}

/**
 * Constructs and returns the full path to a file.
 *
 * @param filePath - The relative path from the base directory to the file, including any folders.
 * @returns The full file path as a string.
 */
export const getDataFilePath = (filePath: string): string => {
  return `${FILE_BASE_PATH}${filePath}`;
};

/**
 * Creates an authenticated API context for making API calls with the required headers.
 * @param request Playwright request object
 * @param token Optional token value (defaults to 'notsupersecret_but_stillakindofpwd')
 * @returns Authenticated API context
 */
export async function createAuthenticatedApiContext(request: any, token = "notsupersecret_but_stillakindofpwd") {
  return await request.newContext({
    extraHTTPHeaders: {
      "x-dhauth-token": token,
      accept: "application/json",
      // 'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)
      // AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36',
      // 'cookie': 'ajs_anonymous_id=...; _ga=...; ...', // Only if needed
    },
  });
}

export const convertFileToBase64 = (fileName: string): string => {
  const filePath = getDataFilePath(fileName); // Get the full file path using the getDataFilePath function
  const absFilePath = path.resolve(filePath);
  try {
    const fileBuffer = fs.readFileSync(absFilePath);
    return fileBuffer.toString("base64"); // Return the base64 encoded data
  } catch (err) {
    throw new Error(`Error reading the file: ${err.message}`);
  }
};
