export class TestDataUtils {
  /**
   * Generates a timestamp in milliseconds since the Unix epoch.
   *
   * @returns A string representing the current timestamp in milliseconds.
   */
  public static generateTimestamp(): string {
    const timestamp = Date.now();
    return timestamp.toString();
  }
}
